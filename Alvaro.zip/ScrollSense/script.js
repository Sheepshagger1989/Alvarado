// Smooth scrolling for navigation links
document.addEventListener('DOMContentLoaded', function() {
    // Get all navigation links
    const navLinks = document.querySelectorAll('.nav-link');
    
    // Add click event listeners to navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Get the target section
            const targetId = this.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            
            if (targetSection) {
                // Calculate offset for fixed navbar
                const navbarHeight = document.querySelector('.navbar').offsetHeight;
                const targetPosition = targetSection.offsetTop - navbarHeight;
                
                // Smooth scroll to target
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Highlight active navigation item based on scroll position
    function highlightActiveNavItem() {
        const sections = document.querySelectorAll('section');
        const navLinks = document.querySelectorAll('.nav-link');
        const navbarHeight = document.querySelector('.navbar').offsetHeight;
        
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop - navbarHeight - 100;
            const sectionHeight = section.offsetHeight;
            
            if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').substring(1) === current) {
                link.classList.add('active');
            }
        });
    }
    
    // Listen for scroll events
    window.addEventListener('scroll', highlightActiveNavItem);
    
    // Call once on load
    highlightActiveNavItem();
    
    // Add animation on scroll for sections
    function animateOnScroll() {
        const elements = document.querySelectorAll('.review-card, .service-card, .contact-item');
        
        elements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            const elementVisible = 150;
            
            if (elementTop < window.innerHeight - elementVisible) {
                element.classList.add('animate');
            }
        });
    }
    
    window.addEventListener('scroll', animateOnScroll);
    animateOnScroll(); // Call once on load
    
    // Add mobile menu toggle functionality
    function addMobileMenuToggle() {
        // Create mobile menu toggle button
        const navContainer = document.querySelector('.nav-container');
        const navMenu = document.querySelector('.nav-menu');
        
        // Check if we're on mobile
        if (window.innerWidth <= 768) {
            // Hide menu by default on mobile
            navMenu.style.display = 'none';
            
            // Create toggle button if it doesn't exist
            if (!document.querySelector('.mobile-toggle')) {
                const toggleButton = document.createElement('button');
                toggleButton.classList.add('mobile-toggle');
                toggleButton.innerHTML = '☰';
                toggleButton.style.cssText = `
                    background: none;
                    border: none;
                    font-size: 1.5rem;
                    cursor: pointer;
                    color: #333;
                `;
                
                navContainer.appendChild(toggleButton);
                
                // Toggle menu on button click
                toggleButton.addEventListener('click', function() {
                    if (navMenu.style.display === 'none' || navMenu.style.display === '') {
                        navMenu.style.display = 'flex';
                        toggleButton.innerHTML = '✕';
                    } else {
                        navMenu.style.display = 'none';
                        toggleButton.innerHTML = '☰';
                    }
                });
                
                // Close menu when a link is clicked
                navLinks.forEach(link => {
                    link.addEventListener('click', function() {
                        if (window.innerWidth <= 768) {
                            navMenu.style.display = 'none';
                            toggleButton.innerHTML = '☰';
                        }
                    });
                });
            }
        } else {
            // Show menu on desktop
            navMenu.style.display = 'flex';
            
            // Remove toggle button if it exists
            const toggleButton = document.querySelector('.mobile-toggle');
            if (toggleButton) {
                toggleButton.remove();
            }
        }
    }
    
    // Call on load and resize
    addMobileMenuToggle();
    window.addEventListener('resize', addMobileMenuToggle);
});

// Add CSS animation classes
const style = document.createElement('style');
style.textContent = `
    .nav-link.active {
        color: #1e3a5f !important;
    }
    
    .nav-link.active::after {
        width: 100% !important;
    }
    
    .animate {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .review-card,
    .service-card,
    .contact-item {
        opacity: 0;
        transform: translateY(30px);
        transition: opacity 0.6s ease, transform 0.6s ease;
    }
    
    .review-card.animate,
    .service-card.animate,
    .contact-item.animate {
        opacity: 1;
        transform: translateY(0);
    }
`;
document.head.appendChild(style);